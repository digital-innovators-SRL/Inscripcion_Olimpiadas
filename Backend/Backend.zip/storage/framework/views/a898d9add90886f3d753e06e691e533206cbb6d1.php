<!DOCTYPE html>
<html>
<head>
    <title>Importar Inscripciones</title>
</head>
<body>
    <h2>Importar Inscripciones desde Excel</h2>

    <?php if(session('success')): ?>
        <div style="color: green;"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div style="color: red;"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(url('/importar-inscripciones')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="archivo">Selecciona archivo Excel:</label>
        <input type="file" name="archivo" required>
        <br><br>
        <button type="submit">Importar</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\ETHAN PIERCE\Desktop\TIS\Inscripcion_Olimpiadas\Backend\resources\views/inscripciones/importar.blade.php ENDPATH**/ ?>