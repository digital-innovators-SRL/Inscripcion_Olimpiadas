<!DOCTYPE html>
<html>
<head>
    <title>Inscripciones</title>
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { padding: 10px; border: 1px solid #ccc; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Listado de Inscripciones</h1>
    <table>
        <thead>
            <tr>
                <th>Estudiante</th>
                <th>CI</th>
                <th>Email</th>
                <th>Competencia</th>
                <th>Área</th>
                <th>Categoría</th>
                <th>Curso</th>
                <th>Tutor</th>
                <th>Contacto Celular</th>
                <th>Contacto Email</th>
            </tr>
        </thead>
        <tbody>
<?php $__currentLoopData = $inscripciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inscripcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($inscripcion->nombres); ?> <?php echo e($inscripcion->apellidos); ?></td>
    <td><?php echo e($inscripcion->ci); ?></td>
    <td><?php echo e($inscripcion->email); ?></td>
    <td><?php echo e($inscripcion->competencia); ?></td>
    <td><?php echo e($inscripcion->area); ?></td>
    <td><?php echo e($inscripcion->categoria); ?></td>
    <td><?php echo e($inscripcion->curso); ?></td>
    <td><?php echo e($inscripcion->tutor); ?></td>
    <td><?php echo e($inscripcion->contacto_celular); ?></td>
    <td><?php echo e($inscripcion->contacto_email); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\ETHAN PIERCE\Desktop\TIS\Inscripcion_Olimpiadas\Backend\resources\views/inscripciones/index.blade.php ENDPATH**/ ?>